﻿
namespace Szalloda
{
    partial class recepcioForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.műveletekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadGuestMenuBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.insertGuestMenuBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.insertGuestPanel = new System.Windows.Forms.Panel();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.bookBtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.lastDayPicker = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ferohelyekBox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.typeBox = new System.Windows.Forms.ComboBox();
            this.ellatasBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.firstDayPicker = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.guestNameBox = new System.Windows.Forms.ComboBox();
            this.booksDTG = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.regBtn = new System.Windows.Forms.Button();
            this.emailcim = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.jelszo = new System.Windows.Forms.TextBox();
            this.felhasznaloNev = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.insertGuestPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.booksDTG)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe Print", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.műveletekToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(1031, 31);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // műveletekToolStripMenuItem
            // 
            this.műveletekToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadGuestMenuBtn,
            this.insertGuestMenuBtn});
            this.műveletekToolStripMenuItem.Name = "műveletekToolStripMenuItem";
            this.műveletekToolStripMenuItem.Size = new System.Drawing.Size(133, 25);
            this.műveletekToolStripMenuItem.Text = "Foglalás műveletek";
            // 
            // loadGuestMenuBtn
            // 
            this.loadGuestMenuBtn.Name = "loadGuestMenuBtn";
            this.loadGuestMenuBtn.Size = new System.Drawing.Size(197, 26);
            this.loadGuestMenuBtn.Text = "Foglalások betöltése";
            this.loadGuestMenuBtn.Click += new System.EventHandler(this.loadGuestMenuBtn_Click);
            // 
            // insertGuestMenuBtn
            // 
            this.insertGuestMenuBtn.Name = "insertGuestMenuBtn";
            this.insertGuestMenuBtn.Size = new System.Drawing.Size(197, 26);
            this.insertGuestMenuBtn.Text = "Foglalások rögzítése";
            this.insertGuestMenuBtn.Click += new System.EventHandler(this.insertGuestMenuBtn_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(14, 39);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1003, 761);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.insertGuestPanel);
            this.tabPage1.Controls.Add(this.booksDTG);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(995, 729);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Foglalások";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // insertGuestPanel
            // 
            this.insertGuestPanel.Controls.Add(this.cancelBtn);
            this.insertGuestPanel.Controls.Add(this.bookBtn);
            this.insertGuestPanel.Controls.Add(this.label6);
            this.insertGuestPanel.Controls.Add(this.lastDayPicker);
            this.insertGuestPanel.Controls.Add(this.label5);
            this.insertGuestPanel.Controls.Add(this.label4);
            this.insertGuestPanel.Controls.Add(this.ferohelyekBox);
            this.insertGuestPanel.Controls.Add(this.label3);
            this.insertGuestPanel.Controls.Add(this.typeBox);
            this.insertGuestPanel.Controls.Add(this.ellatasBox);
            this.insertGuestPanel.Controls.Add(this.label2);
            this.insertGuestPanel.Controls.Add(this.firstDayPicker);
            this.insertGuestPanel.Controls.Add(this.label1);
            this.insertGuestPanel.Controls.Add(this.guestNameBox);
            this.insertGuestPanel.Location = new System.Drawing.Point(271, 336);
            this.insertGuestPanel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.insertGuestPanel.Name = "insertGuestPanel";
            this.insertGuestPanel.Size = new System.Drawing.Size(456, 371);
            this.insertGuestPanel.TabIndex = 5;
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(268, 317);
            this.cancelBtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(124, 34);
            this.cancelBtn.TabIndex = 13;
            this.cancelBtn.Text = "Mégsem";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // bookBtn
            // 
            this.bookBtn.Location = new System.Drawing.Point(73, 317);
            this.bookBtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bookBtn.Name = "bookBtn";
            this.bookBtn.Size = new System.Drawing.Size(124, 34);
            this.bookBtn.TabIndex = 12;
            this.bookBtn.Text = "Foglalás";
            this.bookBtn.UseVisualStyleBackColor = true;
            this.bookBtn.Click += new System.EventHandler(this.bookBtn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 213);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 19);
            this.label6.TabIndex = 11;
            this.label6.Text = "Foglalás vége:";
            // 
            // lastDayPicker
            // 
            this.lastDayPicker.Location = new System.Drawing.Point(26, 237);
            this.lastDayPicker.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lastDayPicker.Name = "lastDayPicker";
            this.lastDayPicker.Size = new System.Drawing.Size(233, 27);
            this.lastDayPicker.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "Foglalás kezdete:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(278, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 19);
            this.label4.TabIndex = 8;
            this.label4.Text = "Férőhely:";
            // 
            // ferohelyekBox
            // 
            this.ferohelyekBox.FormattingEnabled = true;
            this.ferohelyekBox.Location = new System.Drawing.Point(281, 235);
            this.ferohelyekBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ferohelyekBox.Name = "ferohelyekBox";
            this.ferohelyekBox.Size = new System.Drawing.Size(140, 27);
            this.ferohelyekBox.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(278, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 19);
            this.label3.TabIndex = 6;
            this.label3.Text = "Szoba típusa:";
            // 
            // typeBox
            // 
            this.typeBox.FormattingEnabled = true;
            this.typeBox.Location = new System.Drawing.Point(281, 142);
            this.typeBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.typeBox.Name = "typeBox";
            this.typeBox.Size = new System.Drawing.Size(140, 27);
            this.typeBox.TabIndex = 5;
            // 
            // ellatasBox
            // 
            this.ellatasBox.FormattingEnabled = true;
            this.ellatasBox.Location = new System.Drawing.Point(281, 45);
            this.ellatasBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ellatasBox.Name = "ellatasBox";
            this.ellatasBox.Size = new System.Drawing.Size(140, 27);
            this.ellatasBox.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(278, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Ellátás:";
            // 
            // firstDayPicker
            // 
            this.firstDayPicker.Location = new System.Drawing.Point(26, 143);
            this.firstDayPicker.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.firstDayPicker.Name = "firstDayPicker";
            this.firstDayPicker.Size = new System.Drawing.Size(233, 27);
            this.firstDayPicker.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Vendég neve:";
            // 
            // guestNameBox
            // 
            this.guestNameBox.FormattingEnabled = true;
            this.guestNameBox.Location = new System.Drawing.Point(26, 45);
            this.guestNameBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.guestNameBox.Name = "guestNameBox";
            this.guestNameBox.Size = new System.Drawing.Size(233, 27);
            this.guestNameBox.TabIndex = 0;
            // 
            // booksDTG
            // 
            this.booksDTG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.booksDTG.Location = new System.Drawing.Point(-5, 16);
            this.booksDTG.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.booksDTG.Name = "booksDTG";
            this.booksDTG.Size = new System.Drawing.Size(1004, 311);
            this.booksDTG.TabIndex = 4;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.regBtn);
            this.tabPage2.Controls.Add(this.emailcim);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.jelszo);
            this.tabPage2.Controls.Add(this.felhasznaloNev);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Size = new System.Drawing.Size(995, 729);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Recepciós regisztráció";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(398, 261);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 19);
            this.label9.TabIndex = 6;
            this.label9.Text = "Jelszó";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(398, 175);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 19);
            this.label8.TabIndex = 5;
            this.label8.Text = "Email cím";
            // 
            // regBtn
            // 
            this.regBtn.Location = new System.Drawing.Point(472, 350);
            this.regBtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.regBtn.Name = "regBtn";
            this.regBtn.Size = new System.Drawing.Size(87, 34);
            this.regBtn.TabIndex = 4;
            this.regBtn.Text = "Regisztrál";
            this.regBtn.UseVisualStyleBackColor = true;
            this.regBtn.Click += new System.EventHandler(this.regBtn_Click);
            // 
            // emailcim
            // 
            this.emailcim.Location = new System.Drawing.Point(402, 198);
            this.emailcim.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.emailcim.Name = "emailcim";
            this.emailcim.Size = new System.Drawing.Size(235, 27);
            this.emailcim.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(398, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 19);
            this.label7.TabIndex = 2;
            this.label7.Text = "Felhasználónév";
            // 
            // jelszo
            // 
            this.jelszo.Location = new System.Drawing.Point(402, 284);
            this.jelszo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.jelszo.Name = "jelszo";
            this.jelszo.PasswordChar = '*';
            this.jelszo.Size = new System.Drawing.Size(235, 27);
            this.jelszo.TabIndex = 1;
            // 
            // felhasznaloNev
            // 
            this.felhasznaloNev.Location = new System.Drawing.Point(402, 113);
            this.felhasznaloNev.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.felhasznaloNev.Name = "felhasznaloNev";
            this.felhasznaloNev.Size = new System.Drawing.Size(235, 27);
            this.felhasznaloNev.TabIndex = 0;
            // 
            // recepcioForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1031, 818);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Segoe Print", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "recepcioForm";
            this.Text = " ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.recepcioForm_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.insertGuestPanel.ResumeLayout(false);
            this.insertGuestPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.booksDTG)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem műveletekToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadGuestMenuBtn;
        private System.Windows.Forms.ToolStripMenuItem insertGuestMenuBtn;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel insertGuestPanel;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.Button bookBtn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker lastDayPicker;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox ferohelyekBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox typeBox;
        private System.Windows.Forms.ComboBox ellatasBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker firstDayPicker;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox guestNameBox;
        private System.Windows.Forms.DataGridView booksDTG;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox jelszo;
        private System.Windows.Forms.TextBox felhasznaloNev;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button regBtn;
        private System.Windows.Forms.TextBox emailcim;
        private System.Windows.Forms.Label label7;
    }
}

