﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Szalloda.Model;

namespace Szalloda.Repos
{
    partial class Repository
    {
        public Szoba getSzobaAdatok(int roomID)
        {
            MySqlConnection connect = new MySqlConnection(getSqlConnection());
            Szoba sz = null;
            try
            {
                connect.Open();
                string query = "SELECT szoba.ID as szobaID, tipus.tipus as szobaTipus, ellatas.ellatas as szobaEllatas, szoba.ferohely as ferohely, szoba.ar as szobaAr FROM szoba LEFT JOIN tipus ON szoba.tipusID = tipus.ID LEFT JOIN ellatas ON ellatas.ID = szoba.ellatasID WHERE szoba.ID = '"+ roomID + "'";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int szobaID = reader.GetInt32("szobaID");
                    string szobaTipus = reader.GetString("szobaTipus");
                    string szobaEllatas = reader.GetString("szobaEllatas");
                    int ferohely = reader.GetInt32("ferohely");
                    int szobaAr = reader.GetInt32("szobaAr");
                    sz = new Szoba(szobaID, szobaEllatas, szobaTipus, ferohely, szobaAr);                    
                }
                connect.Close();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
            return sz;
        }

        public void fillEllatasBox(ComboBox ellatasBox)
        {
            MySqlConnection connect = new MySqlConnection(getSqlConnection());
            int db = EllatasDarabszam();
            try
            {
                connect.Open();
                string query = "SELECT ellatas.ellatas as nev FROM ellatas";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if(ellatasBox.Items.Count < db)
                    {
                        ellatasBox.Items.Add(reader.GetString("nev"));
                    }
                }
                connect.Close();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }

        public void fillSzobaTipusBox(ComboBox szobaTipusBox)
        {
            MySqlConnection connect = new MySqlConnection(getSqlConnection());
            int db = numberOfTpyes();
            try
            {
                connect.Open();
                string query = "SELECT tipus.tipus as nev FROM tipus";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if(szobaTipusBox.Items.Count < db)
                    {
                        szobaTipusBox.Items.Add(reader.GetString("nev"));
                    }
                }
                connect.Close();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }

        public void fillFerohelyekBox(ComboBox ferohelyekBox)
        {
            if(ferohelyekBox.Items.Count < 3)
            {
                ferohelyekBox.Items.Add(2);
                ferohelyekBox.Items.Add(4);
                ferohelyekBox.Items.Add(6);
            }
            
        }
        

        public int getRoomPrice(int ellatasID, int tipusID, int ferohely)
        {
            int price = 0;
            try
            {
                MySqlConnection connect = new MySqlConnection(getSqlConnection());
                connect.Open();
                string query = "SELECT szoba.ar as szobaAr FROM szoba WHERE szoba.ellatasID = '"+ellatasID+"' AND szoba.tipusID = '"+tipusID+"' AND szoba.ferohely = '"+ferohely+"'";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    price = reader.GetInt32("szobaAr");                                        
                }                
                connect.Close();                
                return price;
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
                return price;
            }                        
        }

        public int getRoomID(int ellatasID, int tipusID, int ferohely)
        {
            int id = -1;
            try
            {
                MySqlConnection connect = new MySqlConnection(getSqlConnection());
                connect.Open();
                string query = "SELECT szoba.ID as szobaID FROM szoba WHERE szoba.ellatasID = '" + ellatasID + "' AND szoba.tipusID = '" + tipusID + "' AND szoba.ferohely = '" + ferohely + "'";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    id = reader.GetInt32("szobaID");

                }
                connect.Close();                
                return id;                
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
                return id;
            }            
        }

        public int getEllatasID(string ellatas)
        {
            int id = -1;
            try
            {
                MySqlConnection connect = new MySqlConnection(getSqlConnection());
                connect.Open();
                string query = "SELECT ellatas.ID as ellatasID FROM ellatas WHERE ellatas.ellatas = '"+ellatas+"'";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    id = reader.GetInt32("ellatasID");

                }
                connect.Close();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
            return id;
        }

        public int getRoomTypeID(string tipus)
        {
            int id = -1;
            try
            {
                MySqlConnection connect = new MySqlConnection(getSqlConnection());
                connect.Open();
                string query = "SELECT tipus.ID as tipusID FROM tipus WHERE tipus.tipus = '"+tipus+"'";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    id = reader.GetInt32("tipusID");

                }
                connect.Close();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
            return id;
        }

        
    }
}