﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Szalloda.Repos
{
    partial class Repository
    {
        private MySqlConnectionStringBuilder mscb = new MySqlConnectionStringBuilder();
        public string getSqlConnection()
        {            
            mscb.Server = "localhost";
            mscb.Database = "zarodolgozat";
            mscb.UserID = "root";
            mscb.Password = "";
            mscb.Port = 3306;
            mscb.SslMode = MySqlSslMode.None;
            mscb.AllowZeroDateTime = true;
            return mscb.ToString();
        }
    }
}
