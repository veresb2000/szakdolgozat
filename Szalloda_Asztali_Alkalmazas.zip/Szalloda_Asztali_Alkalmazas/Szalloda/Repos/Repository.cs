﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Szalloda.Repos
{
    partial class Repository
    {
        public Repository()
        {

        }

        public void closeInsertGuestPanel(Panel insertGuestPanel, ComboBox guestNameBox, ComboBox ellatasBox, ComboBox typeBox, ComboBox ferohelyekBox)
        {
            insertGuestPanel.Visible = false;
            guestNameBox.Items.Clear();
            ellatasBox.Items.Clear();
            typeBox.Items.Clear();
            ferohelyekBox.Items.Clear();
        }

        public void openInsertGuestPanel(Panel insertGuestPanel, ComboBox guestNameBox, ComboBox ellatasBox, ComboBox typeBox, ComboBox ferohelyekBox)
        {
            fillEllatasBox(ellatasBox);
            fillSzobaTipusBox(typeBox);
            fillFerohelyekBox(ferohelyekBox);
            fillGuestNameBox(guestNameBox);
            insertGuestPanel.Visible = true;
            guestNameBox.DropDownStyle = ComboBoxStyle.DropDownList;            
            ellatasBox.DropDownStyle = ComboBoxStyle.DropDownList;
            typeBox.DropDownStyle = ComboBoxStyle.DropDownList;
            ferohelyekBox.DropDownStyle = ComboBoxStyle.DropDownList;
        }
    }
}
