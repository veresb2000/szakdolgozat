﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Szalloda.Model;

namespace Szalloda.Repos
{
    partial class Repository
    {        
        public void LoadBooks(DataGridView booksDTG)
        {
            List<Foglalas> foglalasList = getFoglalasList();
            booksDTG.DataSource = createDT(foglalasList);

        }

        public List<Foglalas> getFoglalasList()
        {
            MySqlConnection connect = new MySqlConnection(getSqlConnection());
            string selectQuery = "SELECT foglalas.ID as foglalasID, foglalas.szobaID as szobaID, foglalas.vendegID as vendegID, foglalas.elsoNap as elsoNap, foglalas.utolsoNap as utolsoNap, foglalas.foglalas_datum as foglalasDatum FROM foglalas";
            List<Foglalas> foglalasList = new List<Foglalas>();
            try
            {
                connect.Open();
                MySqlCommand selectCommand = new MySqlCommand(selectQuery, connect);
                MySqlDataReader reader = selectCommand.ExecuteReader();
                while (reader.Read())
                {
                    int id = reader.GetInt32("foglalasID");
                    int szobaID = reader.GetInt32("szobaID");
                    int vendegID = reader.GetInt32("vendegID");                    
                    DateTime elsoNap = reader.GetDateTime("elsoNap");
                    DateTime utolsoNap = reader.GetDateTime("utolsoNap");
                    DateTime datum = reader.GetDateTime("foglalasDatum");
                    Foglalas f = new Foglalas(id, szobaID, vendegID, elsoNap.ToShortDateString(), utolsoNap.ToShortDateString(), datum.ToShortDateString());
                    foglalasList.Add(f);
                }
                connect.Close();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
            return foglalasList;
        }

        public DataTable createDT(List<Foglalas> foglalasList)
        {            
            DataTable dt = new DataTable();
            dt.Columns.Add("Azonosító", typeof(int));
            dt.Columns.Add("Vendég neve", typeof(string));
            dt.Columns.Add("Szoba típusa", typeof(string));
            dt.Columns.Add("Szoba férőhelyek", typeof(int));
            dt.Columns.Add("Ellátás", typeof(string));
            dt.Columns.Add("Szoba ára", typeof(string));            
            dt.Columns.Add("Foglalás kezdete", typeof(string));
            dt.Columns.Add("Foglalás vége", typeof(string));
            dt.Columns.Add("Foglalás dátuma", typeof(string));
            foreach (Foglalas f in foglalasList)
            {
                string nev = getGuestName(f.getVendegID());
                Szoba sz = getSzobaAdatok(f.getSzobaID());
                dt.Rows.Add(f.getID(), nev, sz.getSzobaTipus(), sz.getFerohely(), sz.getEllatasTipusa(), sz.getAr(), f.getElsoNap(), f.getUtolsoNap(), f.getFoglalasDatum());
            }            
            return dt;
        }

        public void refreshFoglalasDTG(DataGridView dtg)
        {
            List<Foglalas> foglalasList = getFoglalasList();
            DataTable dt = createDT(foglalasList);
            // ide kell tenni a dtg beállítását.
            dtg.DataSource = dt;
        }

        public string getGuestName(int id)
        {
            string nev = "";
            try
            {
                MySqlConnection connect = new MySqlConnection(getSqlConnection());
                connect.Open();                
                string query = "SELECT vendeg.vezetekNev as vezetekNev, vendeg.keresztNev as keresztnev FROM vendeg WHERE vendeg.ID = '"+id+"'";
                MySqlCommand cmd = new MySqlCommand(query, connect);                
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    nev += reader.GetString("vezetekNev") + " " + reader.GetString("keresztNev");
                }
                connect.Close();

            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
            return nev;
        }

        public int numberOfGuests()
        {
            MySqlConnection connect = new MySqlConnection(getSqlConnection());
            int db = 0;
            try
            {
                connect.Open();
                string query = "SELECT COUNT(vendeg.keresztNev) as db FROM vendeg";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    db += reader.GetInt32("db");
                }
                connect.Close();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
            return db;
        }

        public int numberOfTpyes()
        {
            MySqlConnection connect = new MySqlConnection(getSqlConnection());
            int db = 0;
            try
            {
                connect.Open();
                string query = "SELECT COUNT(tipus.tipus) as db FROM tipus";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    db += reader.GetInt32("db");
                }
                connect.Close();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
            return db;
        }
        public void fillGuestNameBox(ComboBox guestNameBox)
        {
            MySqlConnection connect = new MySqlConnection(getSqlConnection());
            int db = numberOfGuests();
            try
            {
                connect.Open();
                string query = "SELECT vendeg.keresztNev as keresztNev, vendeg.vezetekNev as vezetekNev FROM vendeg";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string nev = reader.GetString("vezetekNev") + " " + reader.GetString("keresztNev");                    
                    if(guestNameBox.Items.Count < db)
                    {
                        guestNameBox.Items.Add(nev);
                    }
                }
                connect.Close();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }

        public int EllatasDarabszam()
        {
            MySqlConnection connect = new MySqlConnection(getSqlConnection());
            int db = 0;
            try
            {
                connect.Open();
                string query = "SELECT COUNT(ellatas.ellatas) as db FROM ellatas";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    db += reader.GetInt32("db");
                }
                connect.Close();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
            return db;
        }

        public int getGuestID(string vezetekNev, string keresztNev)
        {
            int id = -1;
            try
            {
                MySqlConnection connect = new MySqlConnection(getSqlConnection());
                connect.Open();
                string query = "SELECT vendeg.ID as guestID FROM vendeg WHERE vendeg.vezeteknev = '" + vezetekNev + "' AND keresztNev = '" + keresztNev + "'";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    id = reader.GetInt32("guestID");
                }

                connect.Close();                
                return id;
                
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
                return id;
            }            
        }

        public void insertBookIntoDb(ComboBox ellatasBox, ComboBox typeBox, ComboBox ferohelyekBox, DateTimePicker firstDay, DateTimePicker lastDay, ComboBox guestNameBox)
        {
            
            try
            {
                Szoba sz = createSzoba(ellatasBox, typeBox, ferohelyekBox);                
                string guestName = guestNameBox.Text;
                string[] seged = guestName.Split(' ');                
                string vezetekNev = seged[0];
                string keresztNev = seged[1];
                int guestID = getGuestID(vezetekNev, keresztNev);                                
                string query = "INSERT INTO `foglalas` (`ID`, `szobaID`, `vendegID`, `elsoNap`, `utolsoNap`, `foglalas_datum`) VALUES (NULL, '"+guestID+"', '"+guestID+"', '"+ firstDay.Value.ToString("yyyy-MM-dd") + "', '"+ lastDay.Value.ToString("yyyy-MM-dd") + "', '"+ DateTime.Now.ToString("yyyy-MM-dd") + "')";
                MySqlConnection connect = new MySqlConnection(getSqlConnection());
                MySqlCommand cmd = new MySqlCommand(query, connect);
                connect.Open();
                cmd.ExecuteNonQuery();
                connect.Close();                
                MessageBox.Show("Sikeresen rögzítette a foglalást!");
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
                MessageBox.Show("Sikertelenül rögzítette a foglalást", "Rögzítési hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public Szoba createSzoba(ComboBox ellatasBox, ComboBox typeBox, ComboBox ferohelyekBox)
        {
            
            string ellatas = ellatasBox.Text;
            string roomType = typeBox.Text;
            int ellatasID = getEllatasID(ellatas);
            int typeID = getRoomTypeID(roomType);            
            int ferohelyek = Convert.ToInt32(ferohelyekBox.Text);
            int roomPrice = getRoomPrice(ellatasID, typeID, ferohelyek);            
            int roomID = getRoomID(ellatasID, typeID, ferohelyek);
            Szoba sz = new Szoba(roomID, ellatas, roomType, ferohelyek, roomPrice);
            return sz;
        }        



        

    }
}
