﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Szalloda.Repos
{
    partial class Repository
    {
        public bool Bejentkezes(TextBox usernameBox, TextBox pwBox)
        {
            string username = usernameBox.Text;
            string pw = hashJelszo(pwBox.Text);
            bool status = false;
            try
            {
                MySqlConnection connect = new MySqlConnection(getSqlConnection());
                connect.Open();
                string query = "SELECT recepcios.ID as recepciosID FROM recepcios WHERE recepcios.felhasznaloNev = '" + username + "' AND recepcios.jelszo = '" + pw + "'";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                MySqlDataReader reader = cmd.ExecuteReader();                
                while (reader.Read())
                {
                    status = true;
                }
                connect.Close();
                return status;

            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
                return status;
            }
            
        }
        public string hashJelszo(string jelszo)
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            byte[] inputBytes = Encoding.ASCII.GetBytes(jelszo);
            byte[] hashBytes = md5.ComputeHash(inputBytes);
            string pw = Convert.ToBase64String(hashBytes); 
            
            return pw;

        }

        public void regRecepcios(TextBox username, TextBox email, TextBox pw)
        {
            try
            {
                string felhasznaloNev = username.Text;
                string emailcim = email.Text;
                string jelszo = hashJelszo(pw.Text);
                MySqlConnection connect = new MySqlConnection(getSqlConnection());
                connect.Open();
                string query = "INSERT INTO `recepcios` (`ID`, `felhasznaloNev`, `email`, `jelszo`) VALUES (NULL, '"+felhasznaloNev+"', '"+emailcim+"', '"+jelszo+"')";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                cmd.ExecuteNonQuery();
                connect.Close();
                MessageBox.Show("Sikeres regisztrálás!");
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
                MessageBox.Show("Hiba a regisztrálás közben!", "Hiba a regisztrációnál!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
