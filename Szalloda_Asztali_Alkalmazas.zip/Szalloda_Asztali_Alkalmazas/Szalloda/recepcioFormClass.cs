﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Szalloda.Repos;

namespace Szalloda
{
    public partial class recepcioForm : Form
    {
        private Repository repo = new Repository();
        private void loadGuestMenuBtn_Click(object sender, EventArgs e)
        {
            repo.LoadBooks(booksDTG);
        }
        private void insertGuestMenuBtn_Click(object sender, EventArgs e)
        {
            repo.openInsertGuestPanel(insertGuestPanel, guestNameBox, ellatasBox, typeBox, ferohelyekBox);            
        }
        private void bookBtn_Click(object sender, EventArgs e)
        {
            repo.insertBookIntoDb(ellatasBox, typeBox, ferohelyekBox, firstDayPicker, lastDayPicker, guestNameBox);
            repo.refreshFoglalasDTG(booksDTG);
        }
        private void cancelBtn_Click(object sender, EventArgs e)
        {
            repo.closeInsertGuestPanel(insertGuestPanel, guestNameBox, ellatasBox, typeBox, ferohelyekBox);
        }
        private void recepcioForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        private void regBtn_Click(object sender, EventArgs e)
        {
            repo.regRecepcios(felhasznaloNev, emailcim, jelszo);
        }

    }
}
